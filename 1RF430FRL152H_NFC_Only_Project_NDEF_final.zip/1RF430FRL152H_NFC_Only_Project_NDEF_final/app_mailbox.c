#include "app_mailbox.h"
#include <string.h>
//#include "app_fram_map.h"


/* ---------------- Persistent FRAM storage ---------------- */
/* These variables live in FRAM and survive power loss. */

#pragma PERSISTENT(g_calib)
#pragma RETAIN(g_calib)
volatile calib_blob_t g_calib =
{
    1U,
    {4096U, 0},
    {4096U, 0},
    {4096U, 0},
    0U
};

#pragma PERSISTENT(g_therapy)
#pragma RETAIN(g_therapy)
volatile therapy_blob_t g_therapy =
{
    1U, 100U, 100U, 100U, 60U, 0U, 0U
};

#pragma PERSISTENT(g_sensor)
#pragma RETAIN(g_sensor)
volatile sensor_blob_t g_sensor =
{
    1U,
    2500U,     /* temp_thermistor_raw: ADC2/TEMP2 */
    2500U,     /* temp_reference_raw:  ADC1/TEMP1 */
    700U,      /* ph_raw */
    1000U,     /* z_raw */
    0U,        /* sample_counter */
    0U,        /* status_flags */
    0U,        /* fault_code */
    0U         /* crc16 */
};

#pragma PERSISTENT(g_device)
#pragma RETAIN(g_device)
volatile device_blob_t g_device =
{
    1U, DEV_STATE_THERAPY_LOCKED, 0U, 0U, 0U, 0U, 0U
};

#pragma PERSISTENT(g_req)
#pragma RETAIN(g_req)
volatile app_req_t g_req =
{
    APP_MAGIC, APP_VERSION, 0U, 0U, 0U, {0}, 0U, 0U
};

#pragma PERSISTENT(g_rsp)
#pragma RETAIN(g_rsp)
volatile app_rsp_t g_rsp =
{
    APP_MAGIC, APP_VERSION, 0U, APP_STATUS_OK, 0U, {0}, 0U, 0U
};


/* ---------------- Internal helpers ---------------- */

static uint16_t crc16_ccitt(const uint8_t *data, uint16_t len)
{
    uint16_t crc = 0xFFFFU;
    uint16_t i;
    uint8_t j;

    for (i = 0U; i < len; i++)
    {
        crc ^= ((uint16_t)data[i] << 8);

        for (j = 0U; j < 8U; j++)
        {
            if ((crc & 0x8000U) != 0U)
            {
                crc = (uint16_t)((crc << 1) ^ 0x1021U);
            }
            else
            {
                crc <<= 1;
            }
        }
    }

    return crc;
}

static void refresh_blob_crc(void)
{
    g_calib.crc16 = crc16_ccitt((const uint8_t *)&g_calib,
                                (uint16_t)(sizeof(g_calib) - 2U));

    g_therapy.crc16 = crc16_ccitt((const uint8_t *)&g_therapy,
                                  (uint16_t)(sizeof(g_therapy) - 2U));

    g_sensor.crc16 = crc16_ccitt((const uint8_t *)&g_sensor,
                                 (uint16_t)(sizeof(g_sensor) - 2U));

    g_device.crc16 = crc16_ccitt((const uint8_t *)&g_device,
                                 (uint16_t)(sizeof(g_device) - 2U));
}

static void rsp_begin(uint16_t seq, uint16_t status)
{
    memset((void *)&g_rsp, 0, sizeof(g_rsp));

    g_rsp.magic   = APP_MAGIC;
    g_rsp.version = APP_VERSION;
    g_rsp.seq     = seq;
    g_rsp.status  = status;
}

static void rsp_finish(void)
{
    g_rsp.flags = APP_FLAG_RESPONSE_READY;
    g_rsp.crc16 = crc16_ccitt((const uint8_t *)&g_rsp,
                              (uint16_t)(sizeof(g_rsp) - 2U));
}


/* ---------------- Sensor acquisition ---------------- */

#define SD14CTL0_REG (*(volatile uint16_t *)0x0700)
#define SD14CTL1_REG (*(volatile uint16_t *)0x0702)
#define SD14MEM0_REG (*(volatile uint16_t *)0x0704)

static uint16_t sd14_sample_once(uint16_t ctl1_value)
{
    uint16_t timeout;
    uint16_t value;

    SD14CTL0_REG = 0x0000U;
    SD14CTL1_REG = ctl1_value;
    SD14CTL0_REG = 0x000DU;      /* SD14SGL + SD14SC + SD14EN */

    timeout = 60000U;
    while (((SD14CTL0_REG & 0x0200U) == 0U) && (timeout != 0U))
    {
        timeout--;
    }

    if (timeout == 0U)
    {
        value = 0xFFFFU;
    }
    else
    {
        value = SD14MEM0_REG;
    }

    SD14CTL0_REG = 0x0000U;
    return value;
}

static void sensor_read_temp_pair_raw(uint16_t *thermistor_raw, uint16_t *reference_raw)
{
    *thermistor_raw = sd14_sample_once(0xD2C2U);  /* ADC2/TEMP2: thermistor */
    *reference_raw  = sd14_sample_once(0xD2C3U);  /* ADC1/TEMP1: reference */
}

static uint16_t sensor_read_ph_raw(void)
{
    return 700U;
}

static uint16_t sensor_read_z_raw(void)
{
    uint16_t raw;

    raw = sd14_sample_once(0x12C0U);  /* ADC0 normal voltage input */

    if (raw == 0xFFFFU)
    {
        return 0xFFFFU;
    }

    /*
     * z_raw 当前临时表示 ADC0 电压，单位 mV。
     * SD14: 14-bit, full scale = 0.9V, PGA gain = 1
     * Voltage_mV = raw * 900 / 16383
     */
    return (uint16_t)(((uint32_t)raw * 900UL) / 16383UL);
}

void app_sensor_refresh_stub(void)
{
    uint16_t temp_thermistor_raw;
    uint16_t temp_reference_raw;
    uint16_t ph_raw;
    uint16_t z_raw;

    sensor_read_temp_pair_raw(&temp_thermistor_raw, &temp_reference_raw);
    ph_raw = sensor_read_ph_raw();
    z_raw  = sensor_read_z_raw();

    g_sensor.temp_thermistor_raw = temp_thermistor_raw;
    g_sensor.temp_reference_raw  = temp_reference_raw;
    g_sensor.ph_raw              = ph_raw;
    g_sensor.z_raw               = z_raw;

    g_sensor.sample_counter++;

    if ((temp_thermistor_raw == 0xFFFFU) ||
        (temp_reference_raw == 0xFFFFU) ||
        (z_raw == 0xFFFFU))
    {
        g_sensor.status_flags = 0U;
        g_sensor.fault_code   = 1U;
    }
    else
    {
        g_sensor.status_flags = DEV_STATE_SENSOR_VALID;
        g_sensor.fault_code   = 0U;
    }

    refresh_blob_crc();
}


/* ---------------- Command handlers ---------------- */

static void handle_read_sensor(uint16_t seq)
{
    sensor_rsp_t rsp;

    /*
     * 真实采样版：
     * ADC2/TEMP2 -> temp_thermistor_raw
     * ADC1/TEMP1 -> temp_reference_raw
     * ADC0       -> z_raw，单位 mV
     */
    app_sensor_refresh_stub();

    rsp.temp_thermistor_raw = g_sensor.temp_thermistor_raw;
    rsp.temp_reference_raw  = g_sensor.temp_reference_raw;
    rsp.ph_raw              = g_sensor.ph_raw;
    rsp.z_raw               = g_sensor.z_raw;
    rsp.sample_counter      = g_sensor.sample_counter;
    rsp.status_flags        = g_sensor.status_flags;
    rsp.fault_code          = g_sensor.fault_code;

    rsp_begin(seq, APP_STATUS_OK);

    g_rsp.payload_len = (uint16_t)sizeof(rsp);
    memcpy((void *)g_rsp.payload, (const void *)&rsp, sizeof(rsp));

    rsp_finish();
}


/* ---------------- Public APIs ---------------- */

void app_mailbox_init(void)
{
    g_device.boot_counter++;
    g_device.status_flags |= DEV_STATE_THERAPY_LOCKED;

    /*
     * g_req 是临时请求区。
     * 每次 RF430 启动时强制清空，避免上一次掉场残留 APP_FLAG_EXECUTE。
     */
    memset((void *)&g_req, 0, sizeof(g_req));

    g_req.magic   = APP_MAGIC;
    g_req.version = APP_VERSION;
    g_req.crc16 = crc16_ccitt((const uint8_t *)&g_req,
                              (uint16_t)(sizeof(g_req) - 2U));

    /*
     * g_rsp 是临时响应区。
     * 每次启动时清成空响应。
     */
    memset((void *)&g_rsp, 0, sizeof(g_rsp));

    g_rsp.magic   = APP_MAGIC;
    g_rsp.version = APP_VERSION;
    g_rsp.status  = APP_STATUS_OK;
    g_rsp.crc16 = crc16_ccitt((const uint8_t *)&g_rsp,
                              (uint16_t)(sizeof(g_rsp) - 2U));

    refresh_blob_crc();
}

void app_mailbox_process(void)
{
    uint16_t req_crc;
    uint16_t seq;
    uint16_t cmd;
    uint16_t payload_len;

    if (g_req.magic != APP_MAGIC)
    {
        return;
    }

    if (g_req.version != APP_VERSION)
    {
        return;
    }

    if ((g_req.flags & APP_FLAG_EXECUTE) == 0U)
    {
        return;
    }

    /*
     * 先复制本次请求的关键字段。
     * 后面立刻清 g_req.flags，避免处理过程中掉场导致 flags 永久残留。
     */
    seq         = g_req.seq;
    cmd         = g_req.cmd;
    payload_len = g_req.payload_len;

    /*
     * 当前仍是调试版：
     * 只计算 CRC，不比较。
     * 等 App 写 g_req 稳定后，再恢复正式 CRC 检查。
     */
    req_crc = crc16_ccitt((const uint8_t *)&g_req,
                          (uint16_t)(sizeof(g_req) - 2U));
    (void)req_crc;

    /*
     * 关键：先清执行标志。
     * 这样即使 ADC 采样或响应写入过程中掉场，下次进场也不会重复执行旧请求。
     */
    g_req.flags = 0U;
    g_req.crc16 = crc16_ccitt((const uint8_t *)&g_req,
                              (uint16_t)(sizeof(g_req) - 2U));

    g_device.last_cmd = cmd;
    g_device.last_status = APP_STATUS_BUSY;
    refresh_blob_crc();

    /*
     * 当前阶段只开放读传感器命令，避免 App 半包写入时误触发其他命令。
     */
    switch (cmd)
    {
    case CMD_READ_SENSOR_DATA:
        if (payload_len != 0U)
        {
            rsp_begin(seq, APP_STATUS_BAD_LEN);
            rsp_finish();
        }
        else
        {
            handle_read_sensor(seq);
        }
        break;

    default:
        rsp_begin(seq, APP_STATUS_BAD_CMD);
        rsp_finish();
        break;
    }

    g_device.last_status = g_rsp.status;
    refresh_blob_crc();
}