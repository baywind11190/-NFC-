################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
CMD_SRCS += \
../lnk_rf430frl152h_NFC_Only.cmd 

C_SRCS += \
../NDEF.c \
../app_mailbox.c \
../main.c \
../patch.c 

C_DEPS += \
./NDEF.d \
./app_mailbox.d \
./main.d \
./patch.d 

OBJS += \
./NDEF.obj \
./app_mailbox.obj \
./main.obj \
./patch.obj 

OBJS__QUOTED += \
"NDEF.obj" \
"app_mailbox.obj" \
"main.obj" \
"patch.obj" 

C_DEPS__QUOTED += \
"NDEF.d" \
"app_mailbox.d" \
"main.d" \
"patch.d" 

C_SRCS__QUOTED += \
"../NDEF.c" \
"../app_mailbox.c" \
"../main.c" \
"../patch.c" 


