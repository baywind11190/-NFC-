# FIXED

main.obj: ../main.c
main.obj: ../NDEF.h
main.obj: D:/working_soft_pro/ccs/ccs/ccs_base/msp430/include/rf430frl152h.h
main.obj: D:/working_soft_pro/ccs/ccs/ccs_base/msp430/include/in430.h
main.obj: D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics.h
main.obj: D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics_legacy_undefs.h
main.obj: ../types.h
main.obj: ../patch.h
main.obj: ../app_mailbox.h
main.obj: D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/stdint.h
main.obj: D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_ti_config.h
main.obj: D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/linkage.h
main.obj: D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_stdint40.h
main.obj: D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/stdint.h
main.obj: D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/cdefs.h
main.obj: D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/_types.h
main.obj: D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/machine/_types.h
main.obj: D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/machine/_stdint.h
main.obj: D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/_stdint.h

../main.c:

../NDEF.h:

D:/working_soft_pro/ccs/ccs/ccs_base/msp430/include/rf430frl152h.h:

D:/working_soft_pro/ccs/ccs/ccs_base/msp430/include/in430.h:

D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics.h:

D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics_legacy_undefs.h:

../types.h:

../patch.h:

../app_mailbox.h:

D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/stdint.h:

D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_ti_config.h:

D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/linkage.h:

D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_stdint40.h:

D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/stdint.h:

D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/cdefs.h:

D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/_types.h:

D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/machine/_types.h:

D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/machine/_stdint.h:

D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/_stdint.h:

