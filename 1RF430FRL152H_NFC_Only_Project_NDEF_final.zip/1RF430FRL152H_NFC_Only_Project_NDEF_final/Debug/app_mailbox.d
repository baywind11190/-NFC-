# FIXED

app_mailbox.obj: ../app_mailbox.c
app_mailbox.obj: ../app_mailbox.h
app_mailbox.obj: D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/stdint.h
app_mailbox.obj: D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_ti_config.h
app_mailbox.obj: D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/linkage.h
app_mailbox.obj: D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_stdint40.h
app_mailbox.obj: D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/stdint.h
app_mailbox.obj: D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/cdefs.h
app_mailbox.obj: D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/_types.h
app_mailbox.obj: D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/machine/_types.h
app_mailbox.obj: D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/machine/_stdint.h
app_mailbox.obj: D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/_stdint.h
app_mailbox.obj: D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/string.h
app_mailbox.obj: D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/xlocale/_string.h

../app_mailbox.c:

../app_mailbox.h:

D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/stdint.h:

D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_ti_config.h:

D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/linkage.h:

D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_stdint40.h:

D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/stdint.h:

D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/cdefs.h:

D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/_types.h:

D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/machine/_types.h:

D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/machine/_stdint.h:

D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/_stdint.h:

D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/string.h:

D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/xlocale/_string.h:

