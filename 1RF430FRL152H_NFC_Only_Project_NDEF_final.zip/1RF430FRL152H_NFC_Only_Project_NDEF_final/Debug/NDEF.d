# FIXED

NDEF.obj: ../NDEF.c
NDEF.obj: ../types.h
NDEF.obj: ../NDEF.h
NDEF.obj: D:/working_soft_pro/ccs/ccs/ccs_base/msp430/include/rf430frl152h.h
NDEF.obj: D:/working_soft_pro/ccs/ccs/ccs_base/msp430/include/in430.h
NDEF.obj: D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics.h
NDEF.obj: D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics_legacy_undefs.h
NDEF.obj: ../patch.h
NDEF.obj: D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/string.h
NDEF.obj: D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_ti_config.h
NDEF.obj: D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/linkage.h
NDEF.obj: D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/cdefs.h
NDEF.obj: D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/xlocale/_string.h

../NDEF.c:

../types.h:

../NDEF.h:

D:/working_soft_pro/ccs/ccs/ccs_base/msp430/include/rf430frl152h.h:

D:/working_soft_pro/ccs/ccs/ccs_base/msp430/include/in430.h:

D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics.h:

D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics_legacy_undefs.h:

../patch.h:

D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/string.h:

D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_ti_config.h:

D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/linkage.h:

D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/cdefs.h:

D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/xlocale/_string.h:

