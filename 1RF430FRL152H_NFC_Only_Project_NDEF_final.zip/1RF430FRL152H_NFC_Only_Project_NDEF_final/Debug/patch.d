# FIXED

patch.obj: ../patch.c
patch.obj: ../patch.h
patch.obj: ../types.h
patch.obj: ../NDEF.h
patch.obj: D:/working_soft_pro/ccs/ccs/ccs_base/msp430/include/rf430frl152h.h
patch.obj: D:/working_soft_pro/ccs/ccs/ccs_base/msp430/include/in430.h
patch.obj: D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics.h
patch.obj: D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics_legacy_undefs.h

../patch.c:

../patch.h:

../types.h:

../NDEF.h:

D:/working_soft_pro/ccs/ccs/ccs_base/msp430/include/rf430frl152h.h:

D:/working_soft_pro/ccs/ccs/ccs_base/msp430/include/in430.h:

D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics.h:

D:/working_soft_pro/ccs/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics_legacy_undefs.h:

