#ifndef APP_FRAM_MAP_H_
#define APP_FRAM_MAP_H_

/* RF430FRL152H ISO15693 block size:
 * current NFC project / phone side first按4-byte块来规划
 */
#define ISO_BLOCK_SIZE               4U

/* 固定 FRAM 区基地址
 * 这个地址后面要和 linker command file 对齐
 */
#define APP_FRAM_BASE                0xF888

/* 各区偏移（单位：字节） */
#define APP_OFF_SENSOR               0x00
#define APP_OFF_CALIB                0x20
#define APP_OFF_THERAPY              0x40
#define APP_OFF_DEVICE               0x60
#define APP_OFF_REQ                  0x80
#define APP_OFF_RSP                  0xC0

/* 绝对地址 */
#define APP_ADDR_SENSOR              (APP_FRAM_BASE + APP_OFF_SENSOR)
#define APP_ADDR_CALIB               (APP_FRAM_BASE + APP_OFF_CALIB)
#define APP_ADDR_THERAPY             (APP_FRAM_BASE + APP_OFF_THERAPY)
#define APP_ADDR_DEVICE              (APP_FRAM_BASE + APP_OFF_DEVICE)
#define APP_ADDR_REQ                 (APP_FRAM_BASE + APP_OFF_REQ)
#define APP_ADDR_RSP                 (APP_FRAM_BASE + APP_OFF_RSP)

/* 换算成 ISO15693 block 编号 */
#define APP_BLOCK_SENSOR             ((APP_ADDR_SENSOR  - 0xF868) / ISO_BLOCK_SIZE)
#define APP_BLOCK_CALIB              ((APP_ADDR_CALIB   - 0xF868) / ISO_BLOCK_SIZE)
#define APP_BLOCK_THERAPY            ((APP_ADDR_THERAPY - 0xF868) / ISO_BLOCK_SIZE)
#define APP_BLOCK_DEVICE             ((APP_ADDR_DEVICE  - 0xF868) / ISO_BLOCK_SIZE)
#define APP_BLOCK_REQ                ((APP_ADDR_REQ     - 0xF868) / ISO_BLOCK_SIZE)
#define APP_BLOCK_RSP                ((APP_ADDR_RSP     - 0xF868) / ISO_BLOCK_SIZE)

#endif
