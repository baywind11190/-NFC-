#ifndef APP_MAILBOX_H_
#define APP_MAILBOX_H_

#include <stdint.h>

/* ---------------- Protocol constants ---------------- */

#define APP_MAGIC               (0x52463433UL)   /* "RF43" */
#define APP_VERSION             (0x0001U)

#define APP_FLAG_EXECUTE        (0x0001U)
#define APP_FLAG_RESPONSE_READY (0x0002U)

/* Command IDs */
#define CMD_READ_SENSOR_DATA    (0x01U)
#define CMD_WRITE_CALIB         (0x02U)
#define CMD_WRITE_THERAPY_PARAM (0x03U)
#define CMD_THERAPY_CONTROL     (0x04U)

/* Therapy control actions */
#define THERAPY_STOP            (0x00U)
#define THERAPY_START           (0x01U)   /* blocked in this safe base version */
#define THERAPY_ESTOP           (0x02U)

/* Status codes */
#define APP_STATUS_OK           (0x0000U)
#define APP_STATUS_BUSY         (0x0001U)
#define APP_STATUS_BAD_MAGIC    (0x0002U)
#define APP_STATUS_BAD_LEN      (0x0003U)
#define APP_STATUS_BAD_CRC      (0x0004U)
#define APP_STATUS_BAD_CMD      (0x0005U)
#define APP_STATUS_BAD_PARAM    (0x0006U)
#define APP_STATUS_LOCKED       (0x0007U)

/* Device state flags */
#define DEV_STATE_SENSOR_VALID    (0x0001U)
#define DEV_STATE_THERAPY_LOCKED  (0x0002U)
#define DEV_STATE_ESTOP_LATCHED   (0x0004U)

/* ---------------- Data structures ---------------- */

typedef struct
{
    uint16_t gain_q12;
    int16_t  offset;
} chan_cal_t;

typedef struct
{
    uint16_t version;
    chan_cal_t temp_cal;
    chan_cal_t ph_cal;
    chan_cal_t z_cal;
    uint16_t crc16;
} calib_blob_t;

typedef struct
{
    uint16_t version;
    uint16_t pulse_uA;
    uint16_t pulse_ms;
    uint16_t duty_permille;
    uint16_t session_s;
    uint16_t ionto_level;
    uint16_t crc16;
} therapy_blob_t;

typedef struct
{
    uint16_t version;
    uint16_t temp_thermistor_raw;   /* ADC2/TEMP2: thermistor branch raw value */
    uint16_t temp_reference_raw;    /* ADC1/TEMP1: 100k reference branch raw value */
    uint16_t ph_raw;
    uint16_t z_raw;
    uint16_t sample_counter;
    uint16_t status_flags;
    uint16_t fault_code;
    uint16_t crc16;
} sensor_blob_t;

typedef struct
{
    uint16_t version;
    uint16_t status_flags;
    uint16_t fault_code;
    uint16_t last_cmd;
    uint16_t last_status;
    uint16_t boot_counter;
    uint16_t crc16;
} device_blob_t;

typedef struct
{
    uint32_t magic;
    uint16_t version;
    uint16_t seq;
    uint16_t cmd;
    uint16_t payload_len;
    uint8_t  payload[32];
    uint16_t flags;
    uint16_t crc16;
} app_req_t;

typedef struct
{
    uint32_t magic;
    uint16_t version;
    uint16_t seq;
    uint16_t status;
    uint16_t payload_len;
    uint8_t  payload[40];
    uint16_t flags;
    uint16_t crc16;
} app_rsp_t;

typedef struct
{
    uint16_t temp_thermistor_raw;   /* ADC2/TEMP2: thermistor branch raw value */
    uint16_t temp_reference_raw;    /* ADC1/TEMP1: 100k reference branch raw value */
    uint16_t ph_raw;
    uint16_t z_raw;
    uint16_t sample_counter;
    uint16_t status_flags;
    uint16_t fault_code;
} sensor_rsp_t;

typedef struct
{
    uint8_t action;
    uint8_t reserved;
} therapy_ctl_req_t;

/* ---------------- External FRAM objects ---------------- */

extern volatile calib_blob_t   g_calib;
extern volatile therapy_blob_t g_therapy;
extern volatile sensor_blob_t  g_sensor;
extern volatile device_blob_t  g_device;
extern volatile app_req_t      g_req;
extern volatile app_rsp_t      g_rsp;

/* ---------------- APIs ---------------- */

void app_mailbox_init(void);
void app_mailbox_process(void);
void app_sensor_refresh_stub(void);

#endif