# CCS Installation directory

CCS installed at `D:/working_soft_pro/ccs`.
